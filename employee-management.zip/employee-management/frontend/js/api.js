// Small wrapper around fetch(): adds the token, parses JSON, throws readable errors.
const API = '/api';

const Auth = {
  get token() { return localStorage.getItem('token'); },
  get user() { try { return JSON.parse(localStorage.getItem('user')); } catch { return null; } },
  save(token, user) { localStorage.setItem('token', token); localStorage.setItem('user', JSON.stringify(user)); },
  clear() { localStorage.removeItem('token'); localStorage.removeItem('user'); },
};

async function request(path, options = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (Auth.token) headers.Authorization = 'Bearer ' + Auth.token;

  let res;
  try {
    res = await fetch(API + path, { ...options, headers });
  } catch {
    throw new ApiError('Cannot reach the server. Check that the backend is running.', 0);
  }

  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && !path.startsWith('/auth/')) {
      Auth.clear();
      location.href = 'login.html';
    }
    throw new ApiError(body.message || 'Something went wrong', res.status, body.errors);
  }
  return body;
}

class ApiError extends Error {
  constructor(message, status, fields) { super(message); this.status = status; this.fields = fields || {}; }
}

const api = {
  login: (data) => request('/auth/login', { method: 'POST', body: JSON.stringify(data) }),
  list: (params) => request('/employees?' + new URLSearchParams(params)),
  create: (data) => request('/employees', { method: 'POST', body: JSON.stringify(data) }),
  update: (id, data) => request('/employees/' + id, { method: 'PUT', body: JSON.stringify(data) }),
  remove: (id) => request('/employees/' + id, { method: 'DELETE' }),
};
