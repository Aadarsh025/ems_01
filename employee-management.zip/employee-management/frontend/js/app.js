if (!Auth.token) location.href = 'login.html';

const user = Auth.user || {};
const isAdmin = user.role === 'admin';

const state = { search: '', department: '', sortBy: 'createdAt', order: 'desc', page: 1, limit: 8, pages: 1, total: 0 };
const $ = (id) => document.getElementById(id);
const els = {
  body: $('rows'), status: $('status'), count: $('count'), pageInfo: $('page-info'),
  prev: $('prev'), next: $('next'), search: $('search'), dept: $('department'),
  formDlg: $('form-dialog'), form: $('emp-form'), formTitle: $('form-title'), saveBtn: $('save'),
  delDlg: $('delete-dialog'), delText: $('delete-text'), delBtn: $('confirm-delete'), toast: $('toast'),
};
let editingId = null, deletingId = null, employeesById = {}, toastTimer;

const money = (n) => '₹' + Number(n).toLocaleString('en-IN');
const fmtDate = (d) => new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/* ---------- header ---------- */
$('user-name').textContent = `${user.name || 'User'} (${user.role})`;
$('logout').onclick = () => { Auth.clear(); location.href = 'login.html'; };
if (!isAdmin) { $('add-btn').classList.add('hidden'); $('actions-th').classList.add('hidden'); }

/* ---------- loading data ---------- */
async function load() {
  showState('loading');
  try {
    const { data, total, pages, departments } = await api.list({
      search: state.search, department: state.department, sortBy: state.sortBy,
      order: state.order, page: state.page, limit: state.limit,
    });
    state.total = total; state.pages = pages;
    employeesById = Object.fromEntries(data.map((e) => [e._id, e]));
    fillDepartments(departments);
    render(data);
  } catch (err) {
    showState('error', err.message);
  }
}

function fillDepartments(list) {
  const current = state.department;
  els.dept.innerHTML = '<option value="">All departments</option>' +
    list.map((d) => `<option ${d === current ? 'selected' : ''}>${esc(d)}</option>`).join('');
  $('dept-list').innerHTML = list.map((d) => `<option value="${esc(d)}">`).join('');
}

function render(data) {
  els.count.textContent = `${state.total} record${state.total === 1 ? '' : 's'}`;
  els.pageInfo.textContent = `Page ${state.page} of ${state.pages}`;
  els.prev.disabled = state.page <= 1;
  els.next.disabled = state.page >= state.pages;

  if (!data.length) return showState('empty');
  els.status.classList.add('hidden');
  $('table').classList.remove('hidden');

  els.body.innerHTML = data.map((e) => `
    <tr>
      <td class="name-cell"><strong>${esc(e.name)}</strong></td>
      <td data-label="Department"><span class="chip">${esc(e.department)}</span></td>
      <td data-label="Role">${esc(e.role)}</td>
      <td data-label="Salary">${money(e.salary)}</td>
      <td data-label="Join date">${fmtDate(e.joinDate)}</td>
      ${isAdmin ? `<td class="actions-cell"><div class="actions">
        <button class="icon-btn" data-edit="${e._id}" aria-label="Edit ${esc(e.name)}">✎</button>
        <button class="icon-btn del" data-del="${e._id}" aria-label="Delete ${esc(e.name)}">🗑</button>
      </div></td>` : ''}
    </tr>`).join('');
}

function showState(type, msg) {
  $('table').classList.add('hidden');
  els.status.classList.remove('hidden');
  if (type === 'loading') els.status.innerHTML = '<div class="spinner"></div>Loading employees...';
  if (type === 'empty') els.status.innerHTML = '<strong>No employees found</strong><br>Try a different search or add a new employee.';
  if (type === 'error') {
    els.status.innerHTML = `<strong>Could not load employees</strong><br>${esc(msg)}<br><br><button class="btn" id="retry">Try again</button>`;
    $('retry').onclick = load;
  }
}

/* ---------- search, filter, sort, paging ---------- */
let debounce;
els.search.addEventListener('input', () => {
  clearTimeout(debounce);
  debounce = setTimeout(() => { state.search = els.search.value; state.page = 1; load(); }, 300);
});
els.dept.addEventListener('change', () => { state.department = els.dept.value; state.page = 1; load(); });
els.prev.onclick = () => { state.page--; load(); };
els.next.onclick = () => { state.page++; load(); };

document.querySelectorAll('th[data-sort]').forEach((th) => {
  th.querySelector('button').addEventListener('click', () => {
    const key = th.dataset.sort;
    state.order = state.sortBy === key && state.order === 'asc' ? 'desc' : 'asc';
    state.sortBy = key; state.page = 1;
    document.querySelectorAll('th[data-sort]').forEach((h) => {
      h.removeAttribute('aria-sort');
      h.querySelector('.arrow').textContent = '↕';
    });
    th.setAttribute('aria-sort', state.order === 'asc' ? 'ascending' : 'descending');
    th.querySelector('.arrow').textContent = state.order === 'asc' ? '▲' : '▼';
    load();
  });
});

/* ---------- add / edit ---------- */
const fields = ['name', 'department', 'role', 'salary', 'joinDate'];
const today = () => new Date().toISOString().slice(0, 10);

function openForm(emp) {
  editingId = emp ? emp._id : null;
  els.formTitle.textContent = emp ? 'Edit employee' : 'Add employee';
  els.saveBtn.textContent = emp ? 'Save changes' : 'Add employee';
  els.form.reset();
  clearErrors();
  els.form.joinDate.max = today();
  if (emp) {
    els.form.elements.name.value = emp.name;
    els.form.department.value = emp.department;
    els.form.role.value = emp.role;
    els.form.salary.value = emp.salary;
    els.form.joinDate.value = emp.joinDate.slice(0, 10);
  }
  els.formDlg.showModal();
  els.form.elements.name.focus();
}

function clearErrors() {
  fields.forEach((f) => { els.form.elements[f].classList.remove('invalid'); $('err-' + f).textContent = ''; });
  $('form-alert').classList.add('hidden');
}

function setErrors(errors) {
  Object.entries(errors).forEach(([f, msg]) => {
    if (!els.form.elements[f]) return;
    els.form.elements[f].classList.add('invalid');
    $('err-' + f).textContent = msg;
  });
  const first = fields.find((f) => errors[f]);
  if (first) els.form.elements[first].focus();
}

function validate(v) {
  const errors = {};
  if (v.name.length < 2 || v.name.length > 100) errors.name = 'Name must be 2-100 characters';
  if (!v.department) errors.department = 'Department is required';
  if (!v.role) errors.role = 'Role is required';
  if (v.salary === '' || Number.isNaN(Number(v.salary)) || Number(v.salary) <= 0) errors.salary = 'Salary must be a positive number';
  if (!v.joinDate) errors.joinDate = 'Join date is required';
  else if (v.joinDate > today()) errors.joinDate = 'Join date cannot be in the future';
  return errors;
}

els.form.addEventListener('submit', async (e) => {
  e.preventDefault();
  clearErrors();
  const values = {
    name: els.form.elements.name.value.trim(), department: els.form.department.value.trim(),
    role: els.form.role.value.trim(), salary: els.form.salary.value, joinDate: els.form.joinDate.value,
  };
  const errors = validate(values);
  if (Object.keys(errors).length) return setErrors(errors);

  els.saveBtn.disabled = true;
  els.saveBtn.textContent = 'Saving...';
  try {
    if (editingId) await api.update(editingId, values); else await api.create(values);
    els.formDlg.close();
    toast(editingId ? 'Employee updated' : 'Employee added');
    if (!editingId) { state.sortBy = 'createdAt'; state.order = 'desc'; state.page = 1; }
    await load();
  } catch (err) {
    setErrors(err.fields);
    const alert = $('form-alert');
    alert.textContent = err.message; alert.classList.remove('hidden');
  } finally {
    els.saveBtn.disabled = false;
    els.saveBtn.textContent = editingId ? 'Save changes' : 'Add employee';
  }
});

$('add-btn').onclick = () => openForm(null);
$('cancel-form').onclick = $('close-form').onclick = () => els.formDlg.close();

/* ---------- delete ---------- */
els.body.addEventListener('click', (e) => {
  const edit = e.target.closest('[data-edit]');
  const del = e.target.closest('[data-del]');
  if (edit) openForm(employeesById[edit.dataset.edit]);
  if (del) {
    deletingId = del.dataset.del;
    els.delText.textContent = `Delete ${employeesById[deletingId].name}? This permanently removes the record and cannot be undone.`;
    els.delDlg.showModal();
  }
});
$('cancel-delete').onclick = () => els.delDlg.close();
els.delBtn.onclick = async () => {
  els.delBtn.disabled = true; els.delBtn.textContent = 'Deleting...';
  try {
    await api.remove(deletingId);
    els.delDlg.close();
    toast('Employee deleted');
    if (els.body.children.length === 1 && state.page > 1) state.page--;
    await load();
  } catch (err) {
    els.delDlg.close();
    toast(err.message, true);
  } finally {
    els.delBtn.disabled = false; els.delBtn.textContent = 'Delete';
  }
};

/* ---------- toast ---------- */
function toast(msg, isError) {
  els.toast.textContent = msg;
  els.toast.className = 'toast' + (isError ? ' error' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => els.toast.classList.add('hidden'), 3500);
}

load();
