require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('../src/models/User');
const Employee = require('../src/models/Employee');

(async () => {
  await mongoose.connect(process.env.MONGO_URI);
  await Promise.all([User.deleteMany({}), Employee.deleteMany({})]);

  const hash = await bcrypt.hash('Password@123', 10);
  await User.insertMany([
    { name: 'HR Admin', email: 'admin@company.com', password: hash, role: 'admin' },
    { name: 'Team Manager', email: 'manager@company.com', password: hash, role: 'manager' },
    { name: 'Staff Member', email: 'employee@company.com', password: hash, role: 'employee' },
  ]);

  await Employee.insertMany([
    { name: 'Asha Verma', department: 'Engineering', role: 'Backend Developer', salary: 960000, joinDate: '2023-03-12' },
    { name: 'Rohan Mehta', department: 'Finance', role: 'Accounts Lead', salary: 840000, joinDate: '2022-08-02' },
    { name: 'Meera Iyer', department: 'Human Resources', role: 'HR Executive', salary: 600000, joinDate: '2024-01-19' },
    { name: 'Karan Singh', department: 'Marketing', role: 'Content Strategist', salary: 540000, joinDate: '2023-11-07' },
    { name: 'Neha Joshi', department: 'Engineering', role: 'UI Designer', salary: 720000, joinDate: '2024-06-25' },
    { name: 'Vikram Rao', department: 'Sales', role: 'Account Executive', salary: 580000, joinDate: '2021-09-14' },
    { name: 'Pooja Nair', department: 'Operations', role: 'Operations Analyst', salary: 510000, joinDate: '2022-02-21' },
    { name: 'Arjun Patel', department: 'Engineering', role: 'QA Engineer', salary: 620000, joinDate: '2023-07-03' },
  ]);

  console.log('Seeded. Password for all: Password@123 | admin@company.com, manager@company.com, employee@company.com');
  await mongoose.disconnect();
})();
